const swiper = new Swiper(".swiper", {
  loop: true,
  // If we need pagination
  pagination: {
    el: ".swiper-pagination",
  },
  // Navigation arrows
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

const swiper2 = new Swiper(".swiper2", {
  loop: true,
  autoplay: {
    delay: 5000,
  },
  navigation: {
    nextEl: ".swiper2 .swiper-button-next",
    prevEl: ".swiper2 .swiper-button-prev",
  },
});

const swiper3 = new Swiper(".swiper3", {
  loop: true,
  autoplay: {
    delay: 5000,
  },
  slidesPerView: 3,
  spaceBetween: 5,
  navigation: {
    nextEl: ".swiper3 .swiper-button-next",
    prevEl: ".swiper3 .swiper-button-prev",
  },
  effect: "coverflow",
});

const swiper4 = new Swiper(".swiper4", {
  loop: true,
  autoplay: {
    delay: 5000,
  },
  //   slidesPerView: 3,
  spaceBetween: 5,
  navigation: {
    nextEl: ".swiper4 .swiper-button-next",
    prevEl: ".swiper4 .swiper-button-prev",
  },
});
